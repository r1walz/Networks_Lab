#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>

pid_t sane_fork()
{
	pid_t cpid = fork();

	if (cpid < 0) {
		perror("fork failed");
		exit(EXIT_FAILURE);
	}
	return cpid;
}

int print_pid(const char *role)
{
	return printf("PID of %-12s: %ld\n", role, (long) getpid());
}

void execute_child()
{
	print_pid("child");
	pid_t cpid = sane_fork();

	usleep(100);
	if (!cpid)
		print_pid("grand child");
	else {
		wait(NULL);
		cpid = sane_fork();

		if (!cpid)
			print_pid("grand child");
		else
			wait(NULL);
	}
}

int main()
{
	pid_t cpid;
	cpid = sane_fork();

	if (!cpid) {
		execute_child();
	} else {
		cpid = sane_fork();

		if (!cpid) {
			execute_child();
		} else {
			wait(NULL);
			wait(NULL);
			print_pid("parent");
		}
	}

	return 0;
}
